import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';

@Component({
  selector: 'app-open-button',
  imports: [MatButtonModule],
  templateUrl: './open-button.component.html',
  styleUrl: './open-button.component.css'
})
export class OpenButtonComponent {
  constructor(private router: Router){}
  redirectToCountries(){
    this.router.navigate(['/countries']);
  }
}
